// Nav hamburgerburger selections
const burger = document.querySelector("#burger-menu");
const ul = document.querySelector("nav ul");
const nav = document.querySelector("nav");

// Scroll to top selection
const scrollUp = document.querySelector("#scroll-up");

// Select nav links
const navLink = document.querySelectorAll(".nav-link");

// Hamburger menu function
burger.addEventListener("click", () => {
  ul.classList.toggle("show");
});

// Close hamburger menu when a link is clicked
navLink.forEach((link) =>
  link.addEventListener("click", () => {
    ul.classList.remove("show");
  })
);

// scroll to top functionality
scrollUp.addEventListener("click", () => {
  window.scrollTo({
    top: 0,
    left: 0,
    behavior: "smooth",
  });
});


// Form Validator
function validateForm() {
  // Get form values
  var name = document.getElementById("name").value;
  var email = document.getElementById("email").value;
  var message = document.getElementById("message").value;

  // Simple form validation
  if (name === "" || email === "" || message === "") {
    alert("Please fill in all the required fields.");
    return false;
  }

  // Create a mailto link with form data
  var mailtoLink = "mailto:keigneddiey@gmail.com"
    + "?subject=Contact Form Submission"
    + "&body=Name: " + name + "%0D%0A"
    + "Email: " + email + "%0D%0A"
    + "Message: " + message;

  // Open the mail client with the mailto link
  window.location.href = mailtoLink;

  return true;
}
